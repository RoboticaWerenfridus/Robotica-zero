De bestanden voor draadloze camera.
